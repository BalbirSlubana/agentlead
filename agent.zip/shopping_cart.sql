-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2019 at 09:39 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping_cart`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `username`, `password`, `created_at`, `updated_at`) VALUES
(1, 'becfa012770c6e5311710e59cdddebf0', 'becfa012770c6e5311710e59cdddebf0', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `all_leads`
--

CREATE TABLE `all_leads` (
  `id` int(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `user_id` int(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `document` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `id` int(255) NOT NULL,
  `lead_id` int(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `documents`
--

INSERT INTO `documents` (`id`, `lead_id`, `path`) VALUES
(22, 16, 'public/document/O99n1lVPY76Rhp4jd3UmVMfmLySL4aKZTqmRqErn.png'),
(23, 16, 'public/document/t9yY0wdtWbK61WeHT5e7pE3eABP519sQySjUxr1G.png'),
(24, 16, 'public/document/nSfoFurwl7rfGOvwqKA7aLmpp49dvByqstKCQMSd.png'),
(25, 17, 'public/document/fURPelk99DrxakMKrU8j4yjZhoD60KDnISsOYJU2.png');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `title`, `description`, `created_at`, `updated_at`) VALUES
(2, 'Toseef Ansari', 'Testing for Toseef Ansari', '2019-05-02 14:50:03', '2019-05-02 14:50:03'),
(3, 'Rohit Singh', 'Testing for Rohit Singh', '2019-05-02 14:50:23', '2019-05-02 14:50:23');

-- --------------------------------------------------------

--
-- Table structure for table `leads`
--

CREATE TABLE `leads` (
  `id` int(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `age` int(255) DEFAULT NULL,
  `address` text,
  `nationality` varchar(255) DEFAULT NULL,
  `passport_number` varchar(255) DEFAULT NULL,
  `marital_status` varchar(255) DEFAULT NULL,
  `user_id` int(255) DEFAULT NULL,
  `marketer_id` int(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` varchar(255) DEFAULT 'Incomplete',
  `document_status` varchar(255) DEFAULT 'No Action',
  `repository` int(255) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leads`
--

INSERT INTO `leads` (`id`, `name`, `age`, `address`, `nationality`, `passport_number`, `marital_status`, `user_id`, `marketer_id`, `date`, `status`, `document_status`, `repository`) VALUES
(17, 'New Lead', 32, 'Nothing', 'Australian', '1234-5678-9874-5632', 'Single', 2, NULL, '2019-05-24', 'Close', 'Complete Documents', NULL),
(18, 'kuldeep', 25, 'brunswick', 'indian', 'R38834EF', 'Single', 2, NULL, '2019-05-25', 'Incomplete', 'No Action', NULL),
(19, 'kuldeep', 25, 'brunswick', 'indian', 'R38834EF', 'Single', 2, NULL, '2019-05-25', 'Incomplete', 'No Action', NULL),
(20, 'kuldeep', 25, 'brunswick', 'indian', 'R38834EF', 'Single', 2, NULL, '2019-05-25', 'Incomplete', 'No Action', NULL),
(21, 'kuldeep', 25, 'brunswick', 'indian', 'R38834EF', 'Single', 2, NULL, '2019-05-25', 'Incomplete', 'No Action', NULL),
(22, 'Burger', 25, 'Testing', 'Australian', '1234-5678-9012-3456', 'Single', 2, NULL, '2019-05-25', 'Incomplete', 'Incomplete Documents', NULL),
(23, 'Navneet', 30, 'test', 'aud', '000923333', 'Single', 2, NULL, '2019-05-25', 'Complete', 'No Action', NULL),
(24, 'john3', 30, 'Test', 'aus', '12303', 'Single', 2, NULL, '2019-05-25', 'Approved', 'No Action', NULL),
(25, 'rohan', 19, 'nunawading', 'african', 'SADFSDFDSF', 'Single', 2, 34, '2019-05-31', 'Incomplete', 'No Action', NULL),
(26, 'leada', 45, 'haryana', 'indian', 'linjsdfadjkbdsaf', 'Single', 2, 41, '2019-05-31', 'Incomplete', 'No Action', NULL),
(27, 'leadb', 23, 'sdfdsfwesd', 'okjhiujkh', 'iuhiuh', 'Single', 2, 41, '2019-05-31', 'Incomplete', 'No Action', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `lead_id` int(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `message` text COLLATE utf8mb4_unicode_ci,
  `msg_from` int(11) NOT NULL,
  `msg_to` int(11) NOT NULL,
  `to_status` int(255) DEFAULT NULL,
  `from_status` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(7, '2019_05_01_203641_add_role_to_users', 3),
(8, '2019_05_01_203842_add_role_to_users_table', 3),
(9, '2019_05_01_204245_add_role_to_users', 4),
(11, '2019_05_02_081951_add_username_to_users', 6),
(12, '2019_04_09_221019_create_products_table', 7),
(13, '2019_04_12_193549_create_users_table', 7),
(14, '2019_05_01_210814_create_role_table', 7),
(15, '2019_05_02_135401_create_items_table', 8),
(16, '2019_05_07_112801_create_admin_login_table', 9),
(17, '2019_05_20_062851_create_messages_table', 10),
(18, '2019_05_20_063115_create_messages_table', 11);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `imagePath` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `value`, `created_at`, `updated_at`) VALUES
(1, 'Agent', '2019-05-01 18:30:00', '2019-05-01 18:30:00'),
(2, 'Marketer', '2019-05-01 18:30:00', '2019-05-01 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` int(11) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `status` int(255) DEFAULT '1',
  `m_id` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `created_at`, `updated_at`, `username`, `email`, `password`, `role`, `remember_token`, `address`, `status`, `m_id`) VALUES
(1, '2019-05-26 00:13:03', NULL, 'John Doe', 'john@gmail.com', '$2y$10$fR3MA.KZNwSLHtpx6./CZuahNVtz2j3PG64lr2JVqCMOU8IAvHXLu', 2, NULL, 'Testing', 1, NULL),
(2, '2019-05-26 00:13:24', NULL, 'alen', 'alen@gmail.com', '$2y$10$tArKQGDpfM6z1jL1jeZe9.ZPuUl/4TmYqabcpBNFcr7DVd/upfmTG', 1, NULL, 'Testing', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leads`
--
ALTER TABLE `leads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `leads`
--
ALTER TABLE `leads`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
