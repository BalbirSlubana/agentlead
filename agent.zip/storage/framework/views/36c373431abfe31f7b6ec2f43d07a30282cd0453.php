<?php $__env->startSection('title'); ?>
    Shopping Cart Items
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(Session::has('cart')): ?>
        <div class="row">
            <div class="col-md-6 col-sm-6 offset-md-3 offset-sm-3">
                <ul class="list-group">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <strong><?php echo e($product['item']['title']); ?></strong>
                            <span class="badge badge-success">$ <?php echo e($product['price']); ?></span>
                            <div class="btn-group" role="group" aria-label="Button group with nested dropdown float-md-right float-sm-right">
                                <button id="btnGroupDrop1" type="button" class="btn btn-sm btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Action
                                </button>
                                <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                    <a class="dropdown-item" href="javascript:void(0)">Reduce by 1</a>
                                    <a class="dropdown-item" href="javascript:void(0)">Reduce all</a>
                                </div>
                            </div>
                            <span class="badge badge-dark float-md-right"><?php echo e($product['qty']); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-sm-6 offset-md-3 offset-sm-3">
                <strong>Total: $ <?php echo e($totalPrice); ?></strong>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-6 col-sm-6 offset-md-3 offset-sm-3">
                <a href="<?php echo e(route('checkout')); ?>" class="btn btn-success" type="button">Checkout</a>
            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col-md-6 col-sm-6 offset-md-3 offset-sm-3">
                <h1>No Items in Cart!</h1>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>