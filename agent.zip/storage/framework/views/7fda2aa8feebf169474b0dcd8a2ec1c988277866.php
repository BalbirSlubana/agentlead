<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php echo $__env->make('admin.admin_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-md-9 mb-4">
            <div class="tab-content" id="v-pills-tabContent">
                <div class="tab-pane fade show active" id="create" role="tabpanel" aria-labelledby="create-tab">
                    <div class="card">
                        <div class="card-body">
                            <h1>Create Agents / Marketers</h1>
                            <form method="POST" action="javascript:void(0)" id="create_new_user">
                                <div class="form-group">
                                    <label for="username">Username</label>
                                    <input type="text" name="username" class="form-control" id="username" required />
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" name="email" class="form-control" id="email" required />
                                </div>
                                <div class="form-group">
                                    <label for="address">Address</label>
                                    <textarea name="address" class="form-control" id="address" required style="resize:none;"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input type="password" name="password" class="form-control" id="password" required />
                                </div>
                                <div class="form-group">
                                    <label for="role">Role</label>
                                    <select name="role" id="role" class="form-control" required>
                                        <option value="">Select Role</option>
                                        <?php if($roles): ?>
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option data-value="<?php echo e($data->value); ?>" value="<?php echo e($data->id); ?>"><?php echo e($data->value); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="form-group get_marketer">

                                </div>
                                <?php echo e(csrf_field()); ?>

                                <button type="reset" class="btn btn-danger">Reset</button>
                                <button type="submit" class="btn btn-success">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="leads" role="tabpanel" aria-labelledby="leads-tab">
                    <div class="card">
                        <div class="card-body">
                            <h1 class="heading">Leads</h1>
                            <div class="col-md-12 all_lead_info"></div>
                            <div class="table-responsive all_leads"></div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="agents" role="tabpanel" aria-labelledby="agents">
                    <div class="card">
                        <div class="card-body">
                            <h1 class="heading">Agents</h2>
                            <div class="table-responsive all_agents"></div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="marketers" role="tabpanel" aria-labelledby="marketers">
                    <div class="card">
                        <div class="card-body">
                            <h2 class="heading">Marketers</h2>
                            <div class="table-responsive all_marketers"></div>
                        </div>
                    </div>
                </div>
				<div class="tab-pane fade" id="report" role="tabpanel" aria-labelledby="report">
                    <div class="card">
                        <div class="card-body">
                            <h2 class="heading">Reports</h2>
                            <div class="all_reports">
								<p>Choose Report you want</p>
								<div class="row">
								<div class="col-md-6">
									<div class="card reporting" data-toggle="modal" data-target="#mymodal" data-url="<?php echo e(asset('agents/xlsx')); ?>">
										<div class="card-body text-center">
											<div class="card-image">
												<i class="fas fa-book fa-5x"></i>
											</div>
											<hr>
											<strong class="card-title">Registered active/inactive Agents Report</strong>
										</div>
									</div>
								</div>
								
								<div class="col-md-6">
									<div class="card reporting" data-toggle="modal" data-target="#mymodal" data-url="<?php echo e(URL::to('leads/xlsx')); ?>">
										<div class="card-body text-center">
											<div class="card-image">
												<i class="fas fa-file fa-5x"></i>
											</div>
											<hr>
											<strong class="card-title">Open/Incomplete/Completed Leads</strong>
										</div>
									</div>
								</div>
								
								<div class="col-md-6">
									<div class="card reporting" data-toggle="modal" data-target="#mymodal" data-url="<?php echo e(URL::to('leadsacceptreject/xlsx')); ?>">
										<div class="card-body text-center">
											<div class="card-image">
												<i class="fas fa-address-card fa-5x"></i>
											</div>
											<hr>
											<strong class="card-title">Accepted or Rejected Applications</strong>
										</div>
									</div>
								</div>

								<div class="col-md-6">
									<div class="card reporting" data-toggle="modal" data-target="#mymodal" data-url="<?php echo e(URL::to('leads_per_agent/xlsx')); ?>">
										<div class="card-body text-center">
											<div class="card-image">
												<i class="fas fa-paperclip fa-5x"></i>
											</div>
											<hr>
											<strong class="card-title">Applications per Agent</strong>
										</div>
									</div>
								</div>

								<div class="col-md-6">
									<div class="card reporting" data-toggle="modal" data-target="#mymodal" data-url="<?php echo e(URL::to('leads_closing_per_marketer/xlsx')); ?>">
										<div class="card-body text-center">
											<div class="card-image">
												<i class="fas fa-file-alt fa-5x"></i>
											</div>
											<hr>
											<strong class="card-title">Applications closing per Marketer</strong>
										</div>
									</div>
								</div>
								</div>
								<!--<p><a href="<?php echo e(URL::to('agents/xlsx')); ?>"><button class="btn btn-success">Agent Report</button></a></p>
								<p><a href="<?php echo e(URL::to('leads/xlsx')); ?>"><button class="btn btn-success">Leads Report</button></a></p>-->
							</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</div>
	<div class="modal fade" id="mymodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Choose Date Range</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<label for="from">From</label>
				<input type="text" id="from" name="from" class="report_1_from">
				<label for="to">to</label>
				<input type="text" id="to" name="to" class="report_1_to">
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-primary report_1_data">Get Link</button>
				<a href="" class="btn btn-primary report_1_link hidden">Download</a>
			</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
	$(document).ready(function(){
		function check_datatable(){
            if ( $.fn.dataTable.isDataTable( 'table' ) ) {
                table = $('table').DataTable();
            }
            else {
                table = $('table').DataTable();
            }
        }
	
		$("body").delegate("#role","change",function(){
			var role = $(this).val();
			var host = "<?php echo e(URL::to('/')); ?>/";
			if(role == 1){
				$.ajax({
					headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
					type:"POST",
					url:host+"user/get_marketer",
					data:{command:"get_marketer"},
					success:function(result){
						if(result != "NO"){
							$(".get_marketer").html(result);
						}else{
							alert("Create Atleast One Marketer first. \n Marketer will monitor Agents.");
						}
					}
				});
			}
		});

		$('body').delegate('#create_new_user','submit', function(e) {
		   e.preventDefault(); 
		   var form_data = $(this).serialize();
		   var host = "<?php echo e(URL::to('/')); ?>/";
		   //alert(form_data);
		   $.ajax({
			headers: {
			  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			  },
			   type: "POST",
			   url: host+'user/create_new',
			   data: form_data,
			   success: function( msg ) {
					if(msg == "OK"){
						var role = $("#role").val();
						if(role == 1){
							role = "Agent";
						}else{
							role = "Marketer";
						}
						alert("New "+role+" Created");
						window.location.reload();
					}else{
						alert( msg );
						return false;
					}
			   }
		   });
	   });
	   $("#leads-tab").click(function(e){
		   e.preventDefault();
			var host = "<?php echo e(URL::to('/')); ?>/";
			$.ajax({
				headers: {
			  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			  },
			   type: "POST",
			   url: host+'admin/get_leads',
			   data: {command:'get_all_leads'},
			   success: function( msg ) {
				   //alert(msg);
					if(msg){
						$(".all_leads").html(msg);
						//$("table").trigger( "myevent" );
						check_datatable();
					}
			   }
		   });
	   });
	   $("#agents-tab").click(function(e){
		   e.preventDefault();
			var host = "<?php echo e(URL::to('/')); ?>/";
			$.ajax({
				headers: {
			  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			  },
			   type: "POST",
			   url: host+'admin/get_agents',
			   data: {command:'get_all_agents'},
			   success: function( msg ) {
				   //alert(msg);
					if(msg){
						$(".all_agents").html(msg);
						check_datatable();
					}
			   }
		   });
	   });
	   $("#marketers-tab").click(function(e){
		   e.preventDefault();
			var host = "<?php echo e(URL::to('/')); ?>/";
			$.ajax({
				headers: {
			  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			  },
			   type: "POST",
			   url: host+'admin/get_marketers',
			   data: {command:'get_all_marketers'},
			   success: function( msg ) {
				   //alert(msg);
					if(msg){
						$(".all_marketers").html(msg);
						check_datatable();
					}
			   }
		   });
	   });
	   $("body").delegate(".lead_info","click",function(e){
			e.preventDefault();
			var id = $(this).data('id');
			var host = "<?php echo e(URL::to('/')); ?>/";
			$.ajax({
				headers: {
			  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			  },
			   type: "POST",
			   url: host+'admin/get_lead_info',
			   data: {command:'get_lead_info',id:id},
			   success: function( msg ) {
				   //alert(msg);
					if(msg){
						$(".all_lead_info").html(msg);
						$(".all_lead_info").slideDown();
					   // $("table").trigger( "myevent" );
					}
			   }
		   });
	   });
	   $("body").delegate(".close_lead_info","click",function(){
		   $(".all_lead_info").slideUp(300);
		   //$(".all_lead_info").delay(300).empty();
		   //$(".all_lead_info").delay(500).attr("style","display:none;");
	   });	   
	   /*$("body").delegate("#report-tab","click",function(){
		   e.preventDefault();
			var host = "<?php echo e(URL::to('/')); ?>/";
			$.ajax({
				headers: {
			  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			  },
			   type: "POST",
			   url: host+'admin/get_lead_info',
			   data: {command:'get_reports'},
			   success: function( msg ) {
				   //alert(msg);
					if(msg){
						$(".all_reports").html(msg);
						$(".all_reports").slideDown();
					   // $("table").trigger( "myevent" );
					}
			   }
		   });
	   });*/
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\agent\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>