<?php $__env->startSection('title'); ?>
    Checkout
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-6 col-md-4 offset-md-4 offset-sm-3">
            <h1>Checkout</h1>
            <h4>Your Total: $<?php echo e($total); ?></h4>
            <hr>
            <form action="<?php echo e(route('checkout')); ?>" method="POST" id="checkout-form">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" name="name" id="name" class="form-control required" required />
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label for="address">Address</label>
                            <input type="text" name="address" id="address" class="form-control required" required />
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label for="card-name">Card Holder Name</label>
                            <input type="text" name="card-name" id="card-name" class="form-control required" required />
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label for="card-number">Credit / Debit Card number</label>
                            <input type="text" name="card-number" id="card-number" class="form-control required" required />
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="card-expiry-month">Expiration Month</label>
                            <input type="text" name="card-expiry-month" id="card-expiry-month" class="form-control required" required />
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="card-expiry-year">Expiry Year</label>
                            <input type="text" name="card-expiry-year" id="card-expiry-year" class="form-control required" required />
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label for="card-cvc">CVC</label>
                            <input type="text" name="card-cvc" id="card-cvc" class="form-control required" required />
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <input type="submit" value="Buy Now" class="btn btn-success" /> <input type="reset" value="Cancel" class="btn btn-danger" />
                        </div>
                    </div>
                </div>
                <?php echo e(csrf_field()); ?>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="https://js.stripe.com/v3/"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/checkout.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\agent\resources\views/shop/checkout.blade.php ENDPATH**/ ?>