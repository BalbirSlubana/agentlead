<?php $__env->startSection('title'); ?>
    Profile
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4 offset-md-4">
            <div class="row">
                <div class="card">
                    <div class="card-body"><h1>User Profile</h1></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>