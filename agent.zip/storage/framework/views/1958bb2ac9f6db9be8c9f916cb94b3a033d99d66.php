<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script>window.laravel = { csrfToken:'<?php echo e(csrf_token()); ?>' }</script>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Montserrat|Playfair+Display" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/dataTables.uikit.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/uikit.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/lightbox.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.css')); ?>">
    <style>body{font-family: 'Montserrat', sans-serif;}h1{font-family: 'Playfair Display', serif;}</style>
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid">
    <?php echo $__env->yieldContent('content'); ?>
</div>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/datatable_ui.js')); ?>"></script>
<script src="<?php echo e(asset('js/lightbox.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('js/moment.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $("body").delegate(".custom-tabs","click",function(){
            var id = $(this).data('id');
            $(".tabs_content").removeClass('active');
            $(id).addClass('active');
        });
        $("body").delegate(".update_application_status","click",function(){
            var application_status = $(".change_lead_status").val();
            var id = $(this).data('id');
            var host = "<?php echo e(URL::to('/')); ?>/";
            $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"POST",
                url:host+"user/change_application_status",
                data:{id:id,status:application_status},
                success:function(result){
                    if(result == "OK"){
                        alert("Application Status Updated.");
                        window.location.href="profile";
                    }else{
                        alert(result);
                    }
                }
            });
        });
		$("body").delegate(".update_document_status","click",function(){
            var document_status = $(".change_document_status").val();
            var id = $(this).data('id');
            var host = "<?php echo e(URL::to('/')); ?>/";
            $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"POST",
                url:host+"user/change_document_status",
                data:{id:id,status:document_status},
                success:function(result){
                    if(result == "OK"){
                        alert("Document Status Updated.");
                        window.location.href="profile";
                    }else{
                        alert(result);
                    }
                }
            });
        });
		
		$("body").delegate(".save_in_repository","click",function(){
			var id = $(this).data("id");
			var host = "<?php echo e(URL::to('/')); ?>/";
            $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"POST",
                url:host+"user/in_repository",
                data:{id:id},
                success:function(result){
                    if(result == "OK"){
                        alert("Saved into repository.");
                        window.location.href="profile";
                    }else{
                        alert(result);
                    }
                }
            });
		});
		
        function get_message_history(a){
            var host = "<?php echo e(URL::to('/')); ?>/";
            $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"POST",
                url:host+"user/chat_history",
                data:{command:'get_all_history',lead_id:a},
                success:function(result){
                    $(".message_box .all_messages").html(result);
                }
            });
        }
        //setTimeout(function(){get_message_history();},5000);
        function lead_message(a){
            var host = "<?php echo e(URL::to('/')); ?>/";
            $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"POST",
                url:host+"user/lead_message",
                data:{lead_id:a},
                success:function(result){
                    $(".message_box .all_messages").html(result);
                }
            });
        }
        setInterval(function(){
            if($("#lead").val() != null){
                lead_message($("#lead").val());
            }
        },5000);
        $("body").delegate(".messaging","submit",function(){
            var form_data = $(this).serialize();
            var lead = $(this).find('input[name=lead_id]').val();
            var host = "<?php echo e(URL::to('/')); ?>/";
            $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"POST",
                url:host+"user/new_chat_message",
                data:form_data,
                success:function(result){
                    //alert(result);
					$("#message").val("");
                    lead_message(lead);
                }
            });
            return false;
        });
        $("body").delegate("#new_document","submit",function(){
            var form_data = $(this).serialize();
            //alert(form_data);
            var host = "<?php echo e(URL::to('/')); ?>/";
            $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"POST",
                url:host+"user/upload_new_document",
                data:new FormData(this),
                contentType: false,
                cache: false,
                processData:false,
                success:function(result){
                    alert(result);
                }
            });
            return false;
        });

        $("body").delegate(".upload_new_document","click",function(){
            $(".new_document").toggleClass("active");
        });

        var reporting_url = "";

        $("body").delegate(".reporting","click",function(){
            reporting_url = $(this).data("url");
        });

        $("body").delegate(".report_1_data","click",function(){
            var startDate = $(".report_1_from").val();
            var stopDate = $(".report_1_to").val();
            var duration = $("report_1_duration").val();
            $(".report_1_link").attr("href",reporting_url+"/"+startDate+"/"+stopDate);
            $(".report_1_data").addClass("hidden");
            $(".report_1_link").removeClass("hidden");
        });
		
		$("body").delegate(".report_1_link","click",function(){
			setTimeout(function(){
				reporting_url = "";
				$('#mymodal').modal("toggle");
				$(".report_1_from").val("");
				$(".report_1_to").val("");
				$("report_1_duration").val("");
				$(".report_1_link").addClass("hidden");
				$(".report_1_data").removeClass("hidden");
			},1000);
		});

    });
</script>
<script>
    $( function() {
        var dateFormat = "mm/dd/yy",
        from = $( "#from" )
            .datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            numberOfMonths: 3
            })
            .on( "change", function() {
            to.datepicker( "option", "minDate", getDate( this ) );
            }),
        to = $( "#to" ).datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            numberOfMonths: 3
        })
        .on( "change", function() {
            from.datepicker( "option", "maxDate", getDate( this ) );
        });
    
        function getDate( element ) {
        var date;
        try {
            date = $.datepicker.parseDate( dateFormat, element.value );
        } catch( error ) {
            date = null;
        }
    
        return date;
        }
    } );
</script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\agent\resources\views/layouts/master.blade.php ENDPATH**/ ?>