<nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('product.index')); ?>">Shopping Cart</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">

            </ul>
            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('product.shoppingCart')); ?>">
                        <i class="fas fa-shopping-cart"></i>  Shopping Cart 
                        <span class="badge badge-light"><?php echo e(Session::has('cart') ? Session::get('cart')->totalQty : ''); ?></span>
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-user"></i> User Management</a>
                    <div class="dropdown-menu" aria-labelledby="dropdown01">
                        <?php if(Auth::check()): ?>
                        <a class="dropdown-item" href="<?php echo e(route('user.profile')); ?>"><i class="fas fa-user-alt"></i> User Profile</a>
                        <a class="dropdown-item" href="<?php echo e(route('user.logout')); ?>"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        <?php else: ?>
                        <a class="dropdown-item" href="<?php echo e(route('user.signup')); ?>"><i class="fas fa-user"></i> Sign Up</a>
                        <a class="dropdown-item" href="<?php echo e(route('user.signin')); ?>"><i class="fas fa-sign-in-alt"></i> Sign In</a>
                        <?php endif; ?>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav>