@extends('layouts.master')
@section('title')
    Profile
@endsection
@section('content')
    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                    <h1>My Menu</h1>
                    @foreach($role as $role_value)
                        <strong class="badge badge-primary">You : {{ $role_value->value }}</strong>
                    @endforeach
                    <hr>
                    @if(Auth::check())
                        <div class="nav flex-column nav-pills">
                            <a class="nav-link active" href="{{route('user.profile')}}" role="tab" aria-controls="v-pills-home" aria-selected="true"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                            <!--<a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false"><i class="fas fa-plus"></i> Create</a>-->														<a class="nav-link" id="v-pills-leads-tab" data-toggle="pill" href="#v-pills-leads" role="tab" aria-controls="v-pills-leads" aria-selected="false"><i class="fas fa-book"></i> Leads</a>
                            <a class="nav-link" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false"><i class="fas fa-comment-alt"></i> Messaging</a>
                            <a class="nav-link" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false"><i class="fas fa-file-invoice"></i> Reporting</a>
                        </div>
                    @endif
                </div>
            </div>
        </div>
        <div class="col-md-8 mb-4">
            <div class="card">
                <div class="card-body">
                    <h1>{{ $username }}'s Profile</h1>
                    <div class="tab-content" id="v-pills-tabContent">											<div class="tab-pane fade show active" id="v-pills-dashboard" role="tabpanel" aria-labelledby="v-pills-dashboard-tab">                            <h2 class="heading">Latest Leads <a class="btn btn-primary float-right" href="javascript:void(0)" onClick="javascript:alert('Coming soon.');"><i class="fas fa-plus-square"></i> Add New Lead</a></h2>							<div class="table-responsive">                            <table class="table table-bordered table-striped">								<thead>									<tr>										<th>Name</th>										<th>Company</th>										<th>Designation</th>										<th>Mobile</th>									</tr>								</thead>								<tbody>									<tr>										<td>John</td>										<td>Company Name</td>										<td>CEO</td>										<td>+611234567890</td>									</tr>									<tr>										<td>Alex</td>										<td>Company Name</td>										<td>Director</td>										<td>+611234567890</td>									</tr>									<tr>										<td>Stewart</td>										<td>Company Name</td>										<td>Manager</td>										<td>+611234567890</td>									</tr>								</tbody>							</table>							</div>                        </div>						<div class="tab-pane fade" id="v-pills-leads" role="tabpanel" aria-labelledby="v-pills-leads-tab">                            <h2 class="heading">All Leads</h2>							<div class="table-responsive">                            <table class="table table-bordered table-striped">								<thead>									<tr>										<th>Name</th>										<th>Company</th>										<th>Designation</th>										<th>Mobile</th>									</tr>								</thead>								<tbody>									<tr>										<td>John</td>										<td>Company Name</td>										<td>CEO</td>										<td>+611234567890</td>									</tr>									<tr>										<td>Alex</td>										<td>Company Name</td>										<td>Director</td>										<td>+611234567890</td>									</tr>									<tr>										<td>Stewart</td>										<td>Company Name</td>										<td>Manager</td>										<td>+611234567890</td>									</tr>									<tr>										<td>Shane</td>										<td>Company Name</td>										<td>CTO</td>										<td>+611234568790</td>									</tr>									<tr>										<td>Blake</td>										<td>Company Name</td>										<td>Employee</td>										<td>+611234568790</td>									</tr>									<tr>										<td>Natasha</td>										<td>Company Name</td>										<td>Team Leader</td>										<td>+611234568790</td>									</tr>									<tr>										<td>Robert</td>										<td>Company Name</td>										<td>Programmer</td>										<td>+611234568790</td>									</tr>									<tr>										<td>Justin</td>										<td>Company Name</td>										<td>Manager</td>										<td>+611234568790</td>									</tr>									<tr>										<td>Stewen</td>										<td>Company Name</td>										<td>Sales Manager</td>										<td>+611234568790</td>									</tr>									<tr>										<td>Gary</td>										<td>Company Name</td>										<td>Employee</td>										<td>+611234568790</td>									</tr>								</tbody>							</table>							</div>                        </div>
                        <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                            <h2 class="heading">Create New Agent / Marketer</h2>
                            <form method="POST" action="javascript:void(0)" id="create_new_user">
                                    <div class="form-group">
                                        <label for="username">Username</label>
                                        <input type="text" name="username" class="form-control" id="email" required />
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input type="email" name="email" class="form-control" id="email" required />
                                    </div>
                                    <div class="form-group">
                                        <label for="password">Password</label>
                                        <input type="password" name="password" class="form-control" id="password" required />
                                    </div>
                                    <div class="form-group">
                                        <label for="role">Role</label>
                                        <select name="role" id="role" class="form-control" required>
                                                @if($roles)
                                                    @foreach($roles as $data)
                                                        <option value="{{ $data->id }}">{{ $data->value }}</option>
                                                    @endforeach
                                                @endif
                                        </select>
                                    </div>
                                    {{ csrf_field() }}
                                    <button type="reset" class="btn btn-danger">Reset</button>
                                    <button type="submit" class="btn btn-success">Submit</button>
                                </form>
                        </div>
                        <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                            <h2 class="heading">Messageing</h2>
                            <p>Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon.</p>
                        </div>
                        <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                            <h2 class="heading">Reporting</h2>
                            <p>Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon.</p>							<p><a href="{{ URL::to('downloadExcel/xlsx') }}"><button class="btn btn-success">Download demo data</button></a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
      
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="POST" action="javascript:void(0)" id="create_new_user">
                    <div class="modal-body">
                        <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" name="username" class="form-control" id="email" required />
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" name="email" class="form-control" id="email" required />
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" name="password" class="form-control" id="password" required />
                            </div>
                            <div class="form-group">
                                <label for="role">Role</label>
                                <select name="role" id="role" class="form-control" required>
                                        @if($roles)
                                            @foreach($roles as $data)
                                                <option value="{{ $data->id }}">{{ $data->value }}</option>
                                            @endforeach
                                        @endif
                                </select>
                            </div>
                            {{ csrf_field() }}
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-danger">Reset</button>
                        <button type="submit" class="btn btn-success">Submit</button>
                        <button class="btn btn-secondary" data-dismiss="modal" type="button">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection