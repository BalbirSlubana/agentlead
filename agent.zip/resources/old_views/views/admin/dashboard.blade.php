@extends('layouts.master')
@section('title')
    Dashboard
@endsection
@section('content')
    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                    <h1>Admin Menu</h1>
                    <hr>
                    <div class="nav flex-column nav-pills">
                        <a class="nav-link active" href="{{ route('admin.dashboard') }}" role="tab" aria-controls="v-pills-home" aria-selected="true"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                        <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false"><i class="fas fa-plus"></i> Create</a>
                        <a class="nav-link" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">Messages</a>
                        <a class="nav-link" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false">Settings</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-8 mb-4">
            <div class="card">
                <div class="card-body">
                    <h1>Dashboard</h1>
                    <div class="tab-content" id="v-pills-tabContent">
                        <div class="tab-pane fade show active" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                                <h2 class="heading">Create New Agent / Marketer</h2>
                                <form method="POST" action="javascript:void(0)" id="create_new_user">
                                    <div class="form-group">
                                        <label for="username">Username</label>
                                        <input type="text" name="username" class="form-control" id="username" required />
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input type="email" name="email" class="form-control" id="email" required />
                                    </div>
                                    <div class="form-group">
                                        <label for="password">Password</label>
                                        <input type="password" name="password" class="form-control" id="password" required />
                                    </div>
                                    <div class="form-group">
                                        <label for="role">Role</label>
                                        <select name="role" id="role" class="form-control" required>
                                                @if($roles)
                                                    @foreach($roles as $data)
                                                        <option data-value="{{ $data->value }}" value="{{ $data->id }}">{{ $data->value }}</option>
                                                    @endforeach
                                                @endif
                                        </select>
                                    </div>
                                    {{ csrf_field() }}
                                    <button type="reset" class="btn btn-danger">Reset</button>
                                    <button type="submit" class="btn btn-success">Submit</button>
                                </form>
                        </div>
                        <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                            <h2 class="heading">Tab3 Data</h2>
                            <p>Lorem ipsum dolor set amet Lorem ipsum dolor set amet Lorem ipsum dolor set amet Lorem ipsum dolor set amet Lorem ipsum dolor set amet Lorem ipsum dolor set amet Lorem ipsum dolor set amet Lorem ipsum dolor set amet Lorem ipsum dolor set amet.</p>
                        </div>
                        <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                            <h2 class="heading">Tab4 Data</h2>
                            <p>Lorem ipsum dolor set amet Lorem ipsum dolor set amet Lorem ipsum dolor set amet Lorem ipsum dolor set amet Lorem ipsum dolor set amet Lorem ipsum dolor set amet Lorem ipsum dolor set amet Lorem ipsum dolor set amet Lorem ipsum dolor set amet.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
<script>
    $('#create_new_user').on('submit', function(e) {
       e.preventDefault(); 
       var form_data = $(this).serialize();
       var host = "{{ URL::to('/') }}/user/create_new";
       //alert(form_data);
       $.ajax({
           type: "POST",
           url: host,
           data: form_data,
           success: function( msg ) {
                if(msg == "OK"){
                    var role = $("#role").val();
                    if(role == 1){
                        role = "Agent";
                    }else{
                        role = "Marketer";
                    }
                    alert("New "+role+" Created");
                    window.location.reload();
                }else{
                    alert( msg );
                    return false;
                }
           }
       });
   });
</script>
@endsection