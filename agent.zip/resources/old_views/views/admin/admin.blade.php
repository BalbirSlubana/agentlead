@extends('layouts.master')
@section('title')
    Admin login
@endsection
@section('content')
<div class="row">
    <div class="col-md-4 offset-md-4">
        <h1>Admin Panel Login</h1>
        <hr>
        @if(count($errors) > 0)
            <div class="alert alert-danger">
                @foreach($errors as $error)
                <p>{{ $error }}</p>
                @endforeach
            </div>
        @endif
        <form action="{{ route('admin.admin') }}" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" class="form-control" id="username" required />
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" class="form-control" id="password" required />
            </div>
            <button type="submit" class="btn btn-primary">Sign In</button>
            {{ csrf_field() }}
        </form>
    </div>
</div>
@endsection