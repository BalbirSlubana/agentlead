<nav class="navbar navbar-expand-md navbar-dark bg-dark mb-4">
    <div class="container">
        <a class="navbar-brand" href="{{ route('product.index') }}">Laravel Project</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">

            </ul>
            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-user"></i> Menu</a>
                    <div class="dropdown-menu" aria-labelledby="dropdown01">
                        @if(Session::has('admin_logged_in'))
                            <a class="dropdown-item" href="{{ route('admin.dashboard') }}"><i class="fas fa-user-alt"></i> Dashboard</a>
                            <a class="dropdown-item" href="{{ route('admin.logout') }}"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        @else
                            @if(Auth::check())
                            <a class="dropdown-item" href="{{ route('user.profile') }}"><i class="fas fa-user-alt"></i> User Profile</a>
                            <a class="dropdown-item" href="{{ route('user.logout') }}"><i class="fas fa-sign-out-alt"></i> Logout</a>
                            @else
                            <!--<a class="dropdown-item" href="{{ route('user.signup') }}"><i class="fas fa-user"></i> Sign Up</a>-->
                            <a class="dropdown-item" href="{{ route('user.signin') }}"><i class="fas fa-sign-in-alt"></i> Sign In</a>
                            @endif
                        @endif
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav>