@extends('layouts.master')
@section('title')
    Laravel Project Home
@endsection
@section('content')
    @if(count($products) > 0)
        @foreach($products->chunk(3) as $product_data)
        <div class="row products">
            @foreach($product_data as $product)
                <div class="col-md-4 col-sm-4 product">
                    <div class="card">
                        <img src="{{$product->imagePath}}" class="card-img-top" alt="No Image">
                        <hr>
                        <div class="card-body">
                            <h5 class="card-title">{{$product->title}}</h5>
                            <p class="card-text">{{$product->description}}</p>
                            <hr>
                            <div class="row clearfix">
                                <div class="col-md-6 col-xs-6 price">{{$product->price}}</div>
                                <div class="col-md-6 col-xs-6"><a href="{{route('product.addToCart', ['id' => $product->id])}}" class="btn btn-success pull-right"><i class="fas fa-shopping-cart"></i> Add To Cart</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
        @endforeach
    @else
        <p><strong>Welcome to Laravel Project</strong></p>
    @endif
    <!--<div class="col-md-12">
        <a href="{{ URL::to('downloadExcel/xls') }}"><button class="btn btn-success">Download Excel xls</button></a>
        <a href="{{ URL::to('downloadExcel/xlsx') }}"><button class="btn btn-success">Download Excel xlsx</button></a>
        <a href="{{ URL::to('downloadExcel/csv') }}"><button class="btn btn-success">Download CSV</button></a>
        <form style="border: 4px solid #a1a1a1;margin-top: 15px;padding: 10px;" action="{{ URL::to('importExcel') }}" class="form-horizontal" method="post" enctype="multipart/form-data">
            <input type="file" name="import_file" />
            <button class="btn btn-primary" type="submit">Import File</button>
        </form>
    </div>-->
@endsection