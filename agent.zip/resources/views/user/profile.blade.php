@extends('layouts.master')
@section('title')
    Profile
@endsection
@section('content')
    <div class="row">
        <div class="col-md-3 mb-4">
            <div class="card">
                <div class="card-body">
                    <h1>My Menu</h1>
                    @foreach($role as $role_value)
                        <strong class="badge badge-primary">You : {{ $role_value->value }}</strong>
                    @endforeach
                    <hr>
                    @if(Auth::check())
                        @if($role_value->value == "Agent")
                            <div class="nav flex-column nav-pills">
                                <!--<a class="nav-link active" href="#profile" role="tab" aria-controls="profile-tab" aria-selected="true"><i class="fas fa-tachometer-alt"></i> Dashboard</a>-->
								<a class="nav-link active" id="{{ $role_value->value }}-profile-tab" data-toggle="pill" data-id="{{ Auth::user()->id }}" href="#profile" role="tab" aria-controls="leads" aria-selected="false"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                                <a class="nav-link" id="{{ $role_value->value }}-leads-tab" data-toggle="pill" data-id="{{ Auth::user()->id }}" href="#leads" role="tab" aria-controls="leads" aria-selected="false"><i class="fas fa-book"></i> Leads</a>
                                <a class="nav-link" id="{{ $role_value->value }}-messages-tab" data-toggle="pill" data-id="{{ Auth::user()->id }}" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false"><i class="fas fa-comment-alt"></i> Messaging</a>
                                <!--<a class="nav-link" id="{{ $role_value->value }}-settings-tab" data-toggle="pill" data-id="{{ Auth::user()->id }}" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false"><i class="fas fa-file-invoice"></i> Reporting</a>-->
                            </div>
                        @else
                            <div class="nav flex-column nav-pills">
                                <a class="nav-link active" id="{{ $role_value->value }}-profile-tab" data-toggle="pill" data-id="{{ Auth::user()->id }}" href="#profile" role="tab" aria-controls="leads" aria-selected="false"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                                <a class="nav-link" id="{{ $role_value->value }}-agents-tab" data-toggle="pill" href="#agents" role="tab" aria-controls="agents" aria-selected="false"><i class="fas fa-user"></i> Agents</a>
                                <a class="nav-link" id="{{ $role_value->value }}-leads-tab" data-toggle="pill" href="#leads" role="tab" aria-controls="leads" aria-selected="false"><i class="fas fa-book"></i> Leads</a>
                                <!--<a class="nav-link" id="{{ $role_value->value }}-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false"><i class="fas fa-comment-alt"></i> Messaging</a>
                                <a class="nav-link" id="{{ $role_value->value }}-settings-tab" data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false"><i class="fas fa-file-invoice"></i> Reporting</a>-->
                            </div>
                        @endif
                    @endif
                </div>
            </div>
        </div>
        <div class="col-md-9 mb-4">
            <div class="card">
                <div class="card-body">
                    <h1>{{ $username }}'s Profile</h1>
                    <div class="tab-content" id="v-pills-tabContent">
						<div class="tab-pane active show fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                            <div class="card">
                                <div class="card-body">
                                    <h1 class="heading">Personal Information</h1>
                                    <div class="table-responsive profile">
										<p>Username = {{ $username }}</p>
										<p>Email = {{ $email }}</p>
										<p>Account Status = {{ $status }}</p>
										<p>Account Created = {{ $created_at }}</p>
									</div>
                                </div>
                            </div>
							@if(Auth::user()->role == 1)
							@if(count($incomplete) >= 1)
							<div class="card">
                                <div class="card-body">
                                    <h1 class="heading">Notification</h1>
                                    <div class="table-responsive">
										<table id="datatable" class="table table-bordered table-striped uk-table uk-table-hover uk-table-striped">
											<thead>
												<tr>
													<th>Name</th>
													<th>Age</th>
													<th>Nationality</th>
													<th>Passport Number</th>
													<th>Document</th>
												</tr>
											</thead>
											<tbody>
											@foreach($incomplete as $noti)
												<tr>
													<td>{{ $noti['Name'] }}</td>
													<td>{{ $noti['Age'] }}</td>
													<td>{{ $noti['Nationality'] }}</td>
													<td>{{ $noti['Passport_number'] }}</td>
													<td style="color:red;font-weight:bold">{{ $noti['Document'] }}</td>
												</tr>
											@endforeach
											</tbody>
										</table>
									</div>
                                </div>
                            </div>
							@endif
							@endif
                        </div>
                        <div class="tab-pane fade" id="agents" role="tabpanel" aria-labelledby="agents-tab">
                            <div class="card">
                                <div class="card-body">
                                    <h1 class="heading">Agents</h1>
                                    <div class="table-responsive all_agents"></div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="leads" role="tabpanel" aria-labelledby="leads-tab">
                            @if($role_value->value == "Agent")
                                <h2 class="heading">Latest Leads <a class="btn btn-primary float-right new_leads" href="#new_leads"><i class="fas fa-plus-square"></i> Add New Lead</a></h2>
                            @endif
                            <div class="col-md-12 col-lg-12" id="new_leads">
                                <div class="row">
                                    <h3>New Leads Details</h3>
                                    <form id="new_lead" method="post" style="width:100%;" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label for="name">Student Name</label>
                                            <input type="text" name="name" id="name" required class="form-control" />
                                        </div>
                                        <div class="form-group">
                                            <label for="age">Student Age</label>
                                            <input type="text" name="age" id="age" required class="form-control" />
                                        </div>
                                        <div class="form-group">
                                            <label for="address">Student Permanent Address</label>
                                            <textarea name="address" id="address" required class="form-control" style="resize:none;"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label for="nationality">Nationality</label>
                                            <input type="text" name="nationality" id="nationality" required class="form-control" />
                                        </div>
                                        <div class="form-group">
                                            <label for="passport_number">Passport Number</label>
                                            <input type="text" name="passport_number" id="passport_number" required class="form-control" />
                                        </div>
                                        <div class="form-group">
                                            <label for="marital_status">Marital Status</label>
                                            <select name="marital_status" id="marital_status" required class="form-control">
                                                <option value="Single">Single</option>
                                                <option value="Married">Married</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <p class="alert alert-info">
                                                <small><strong>Document :</strong> High School Certificate, 12<sup>th</sup> Certificate, If you are applying for MASTERS, than Undergraduate Certificate, Passport, VISA, English Test Document</small>
                                            </p>
                                            <label for="document">Supporting Document</label>
                                            <input type="file" name="document[]" id="document" required class="form-control" multiple />
                                        </div>
                                        <input type="hidden" name="user_id" value="{{ Auth::user()->id }}" />
                                        <div class="form-group">
                                            <input type="submit" name="submit" id="submit" value="Submit" class="btn btn-success" />
                                            <input type="button" name="reset" id="submit" value="Cancel" data-id="#new_leads" class="btn btn-danger cancel-leads" />
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-body">
                                    <h1 class="heading">Leads</h1>
                                    <div class="col-md-12 all_lead_info"></div>
                                    <div class="table-responsive all_leads"></div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                            <h2 class="heading">Create New Agent / Marketer</h2>
                            <form method="POST" action="javascript:void(0)" id="create_new_user">
                                    <div class="form-group">
                                        <label for="username">Username</label>
                                        <input type="text" name="username" class="form-control" id="email" required />
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input type="email" name="email" class="form-control" id="email" required />
                                    </div>
                                    <div class="form-group">
                                        <label for="password">Password</label>
                                        <input type="password" name="password" class="form-control" id="password" required />
                                    </div>
                                    <div class="form-group">
                                        <label for="role">Role</label>
                                        <select name="role" id="role" class="form-control" required>
                                                @if($roles)
                                                    @foreach($roles as $data)
                                                        <option value="{{ $data->id }}">{{ $data->value }}</option>
                                                    @endforeach
                                                @endif
                                        </select>
                                    </div>
                                    {{ csrf_field() }}
                                    <button type="reset" class="btn btn-danger">Reset</button>
                                    <button type="submit" class="btn btn-success">Submit</button>
                                </form>
                        </div>
                        <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                            <h2 class="heading">Messaging</h2>
                            <div class="agent_messages"></div>
                        </div>
                        <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                            <h2 class="heading">Reporting</h2>
                            <p>Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon Coming Soon.</p>							<p><a href="{{ URL::to('downloadExcel/xlsx') }}"><button class="btn btn-success">Download demo data</button></a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
<script>
    $(document).ready(function(){

        function check_datatable(){
            if ( $.fn.dataTable.isDataTable( 'table' ) ) {
                table = $('table').DataTable();
            }
            else {
                table = $('table').DataTable();
            }
        }

        $(".new_leads").click(function(){
            var h = 800;
            $($(this).attr("href")).attr('style','display:block;');
            $($(this).attr("href")).animate({height:h+"px",top:'-70px', marginBottom:'-70px'});
            return false;
        });
        $(".cancel-leads").click(function(){
            $($(this).data('id')).animate({height:'0px',top:'0px', marginBottom:'0px'});
            setTimeout(function(){$('#new_lead input[type=text]').val("");},650);
            //$($(this).data("id")).delay(500).attr('style','display:none;');
        });
        $("#new_lead").submit(function(){
            //var form_data = $(this).serialize();
            var host = "{{ URL::to('/') }}/";
            $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"POST",
                url:host+"user/submit_new_lead",
                data:new FormData(this),
                contentType: false,
                cache: false,
                processData:false,
                success:function(result){
                    if(result == "OK"){
                        alert("Lead Submitted Successfully.");
                        $("#new_leads").animate({height:'0px',top:'0px'});
                        $("#new_lead input[type=text]").val("");
                        setTimeout(function(){window.location.href="profile";},650);
                    }else{
                        alert(result);
                    }
                }
            });
            return false;
        });

        $("#Agent-leads-tab").click(function(){
            var host = "{{ URL::to('/') }}/";
            $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"POST",
                url:host+"user/get_all_leads",
                data:{id:$(this).data('id')},
                success:function(result){
                    if(result != "NO"){
                        $(".all_leads").html(result);
                        /*$("table").DataTable( {
                            "order": [[ 5, "desc" ]]
                        });*/
                        check_datatable();
                    }else{
                        //alert(result);
                        $(".all_leads").html("No Leads Found.");
                    }
                }
            });
            //return false;
        });
        $("#Agent-messages-tab").click(function(){
            var host = "{{ URL::to('/') }}/";
            $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"POST",
                url:host+"user/get_agent_lead_message",
                data:{id:$(this).data('id')},
                success:function(result){
                    if(result){
                        $(".agent_messages").html(result);
                    }else{
                        //alert(result);
                        $(".agent_messages").html("No Messages found.");
                    }
                }
            });
            //return false;
        });
        
        $("#Marketer-agents-tab").click(function(){
            var host = "{{ URL::to('/') }}/";
            $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"POST",
                url:host+"user/all_agents",
                success:function(result){
                    if(result != "NO"){
                        $(".all_agents").html(result);
                        /*$("table").DataTable( {
                            "order": [[ 4, "desc" ]]
                        });*/
                        check_datatable();
                    }else{
                        $(".all_agents").html("No Agents Found.");
                    }
                }
            });
        });

        $("#Marketer-leads-tab").click(function(){
            var host = "{{ URL::to('/') }}/";
            $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"POST",
                url:host+"user/get_all_leads_marketer",
                data:{id:$(this).data('id')},
                success:function(result){
                    if(result != "NO"){
                        $(".all_leads").html(result);
                        /*$("table").DataTable( {
                            "order": [[ 5, "desc" ]]
                        });*/
                        check_datatable();
                    }else{
                        $(".all_leads").html("No Leads Found.");
                    }
                }
            });
            //return false;
        });

        $("body").delegate(".lead_info","click",function(e){
            e.preventDefault();
            var id = $(this).data('id');
            var host = "{{ URL::to('/') }}/";
            var lead_id = '<input type="hidden" id="lead" value="'+id+'" />';
            $("body").append(lead_id);
            $.ajax({
                headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
                type: "POST",
                url: host+'user/get_lead_info',
                data: {command:'get_lead_info',id:id},
                success: function( msg ) {
                //alert(msg);
                    if(msg){
                        $(".all_lead_info").html(msg);
                        $(".all_lead_info").slideDown();
                    // $("table").trigger( "myevent" );
                    }
                }
            });
        });
        $("body").delegate(".close_lead_info","click",function(){
            $(".all_lead_info").slideUp(300);
            //$(".all_lead_info").delay(300).empty();
            //$(".all_lead_info").delay(500).attr("style","display:none;");
        });

        $("body").delegate(".change_agent_status","change",function(){
            var id = $(this).data("id");
            var status = $(this).val();
            var host = "{{ URL::to('/') }}/";
            //alert(id);
            $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"POST",
                url:host+"user/change_agent_status",
                data:{id:id,status:status},
                success:function(result){
                    if(result == "OK"){
                        $("#Marketer-agents-tab").click();
                    }else{
                        alert(result);
                    }
                }
            });
        });
    
    });
</script>
@endsection