@extends('layouts.master')
@section('title')
    Sign In
@endsection
@section('content')
<div class="row">
    <div class="col-md-4 offset-md-4">
        <h1>Sign In</h1>
        @if(count($errors) > 0)
            <div class="alert alert-danger">
                @foreach($errors->all() as $error)
                <p>{{ $error }}</p>
                @endforeach
            </div>
        @endif
        <form action="{{ route('user.signin') }}" method="POST">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" class="form-control" id="email" required />
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" class="form-control" id="password" required />
            </div>
            <div class="form-group">
                <label for="role">Role</label>
                <select name="role" id="role" class="form-control" required>
                        @if($user_data)
                            @foreach($user_data as $data)
                                <option value="{{ $data->id }}" <?php if(isset($_GET['role'])){if($data->value == $_GET['role']){echo 'selected';}} ?>>{{ $data->value }}</option>
                            @endforeach
                        @endif
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Sign In</button>
            {{ csrf_field() }}
        </form>
        <br>
    </div>
</div>
@endsection