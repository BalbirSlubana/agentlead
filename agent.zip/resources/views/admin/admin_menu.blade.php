<div class="col-md-3 mb-4">
    <div class="card">
        <div class="card-body">
            <h1>Admin Menu</h1>
            <hr>
            <div class="nav flex-column nav-pills">
                <a class="nav-link active" href="{{ route('admin.dashboard') }}" role="tab" aria-controls="v-pills-home" aria-selected="true"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                <a class="nav-link" id="create-tab" data-toggle="pill" href="#create" role="tab" aria-controls="create-tab" aria-selected="false"><i class="fas fa-plus"></i> Create</a>
                <a class="nav-link" id="leads-tab" data-toggle="pill" href="#leads" role="tab" aria-controls="leads" aria-selected="false">Leads</a>
                <a class="nav-link" id="agents-tab" data-toggle="pill" href="#agents" role="tab" aria-controls="agents" aria-selected="false">Agents</a>
                <a class="nav-link" id="marketers-tab" data-toggle="pill" href="#marketers" role="tab" aria-controls="marketers" aria-selected="false">Marketers</a>
                <a class="nav-link" id="report-tab" data-toggle="pill" href="#report" role="tab" aria-controls="report" aria-selected="false">Reports</a>
            </div>
        </div>
    </div>
</div>