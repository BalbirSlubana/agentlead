@extends('layouts.master')
@section('title')
    Laravel Project
@endsection
@section('content')
    <div class="container">
        <h2>Choose the panel you want to use.</h2>
        <div class="row">
            <!-- Agents Panel -->
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 card-wrapper">
                    <a href="{{ route('user.signin') }}?role=Agent">
                        <div class="card">
                            <div class="card-body text-center">
                                <div class="card-image">
                                    <i class="fas fa-user fa-5x"></i>
                                </div>
                                <hr>
                                <strong class="card-title">Agents Panel</strong>
                            </div>
                        </div>
                    </a>
                </div>
            <!-- Marketers Panel -->
            <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 card-wrapper">
                <a href="{{ route('user.signin') }}?role=Marketer">
                    <div class="card">
                        <div class="card-body text-center">
                            <div class="card-image">
                                <i class="fas fa-user fa-5x"></i>
                            </div>
                            <hr>
                            <strong class="card-title">Marketers Panel</strong>
                        </div>
                    </div>
                </a>
            </div>
            <!-- Admin Panel -->
            <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 card-wrapper">
                <a href="{{ route('admin.admin') }}">
                    <div class="card">
                        <div class="card-body text-center">
                            <div class="card-image">
                                <i class="fas fa-user fa-5x"></i>
                            </div>
                            <hr>
                            <strong class="card-title">Admin Panel</strong>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <br>
    </div>
@endsection