@extends('layouts.master')
@section('title')
    Shopping Cart Items
@endsection
@section('content')
    @if(Session::has('cart'))
        <div class="row">
            <div class="col-md-6 col-sm-6 offset-md-3 offset-sm-3">
                <ul class="list-group">
                    @foreach($products as $product)
                        <li class="list-group-item">
                            <strong>{{ $product['item']['title'] }}</strong>
                            <span class="badge badge-success">$ {{ $product['price'] }}</span>
                            <div class="btn-group" role="group" aria-label="Button group with nested dropdown float-md-right float-sm-right">
                                <button id="btnGroupDrop1" type="button" class="btn btn-sm btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Action
                                </button>
                                <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                    <a class="dropdown-item" href="javascript:void(0)">Reduce by 1</a>
                                    <a class="dropdown-item" href="javascript:void(0)">Reduce all</a>
                                </div>
                            </div>
                            <span class="badge badge-dark float-md-right">{{ $product['qty'] }}</span>
                        </li>
                    @endforeach
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-sm-6 offset-md-3 offset-sm-3">
                <strong>Total: $ {{ $totalPrice }}</strong>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-6 col-sm-6 offset-md-3 offset-sm-3">
                <a href="{{ route('checkout') }}" class="btn btn-success" type="button">Checkout</a>
            </div>
        </div>
    @else
        <div class="row">
            <div class="col-md-6 col-sm-6 offset-md-3 offset-sm-3">
                <h1>No Items in Cart!</h1>
            </div>
        </div>
    @endif
@endsection