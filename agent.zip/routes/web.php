<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[
    'uses' => 'ProductController@getIndex',
    'as' => 'product.index'
]);

Route::get('/add-to-cart/{id}',[
    'uses' => 'ProductController@getAddToCart',
    'as' => 'product.addToCart'
]);

Route::get('/shopping-cart',[
    'uses' => 'ProductController@getCart',
    'as' => 'product.shoppingCart'
]);

Route::get('/checkout',[
    'uses' => 'ProductController@getCheckout',
    'as' => 'checkout'
]);

Route::post('/checkout',[
    'uses' => 'ProductController@postCheckout',
    'as' => 'checkout'
]);

Route::group(['prefix' => 'user'], function(){
    Route::group(['middleware' => 'guest'], function(){
        Route::get('/signup',[
            'uses' => 'UserController@getSignup',
            'as' => 'user.signup'
        ]);
        Route::post('/signup',[
            'uses' => 'UserController@postSignup',
            'as' => 'user.signup'
        ]);
        
        Route::get('/signin',[
            'uses' => 'UserController@getSignin',
            'as' => 'user.signin'
        ]);
        
        Route::post('/signin',[
            'uses' => 'UserController@postSignin',
            'as' => 'user.signin'
        ]);
    });
    
    Route::group(['middleware' => 'auth'], function(){
        Route::get('/profile',[
            'uses' => 'UserController@getProfile',
            'as' => 'user.profile'
        ]);

        Route::get('/logout',[
            'uses' => 'UserController@getLogout',
            'as' => 'user.logout'
        ]);
    });
    
    Route::post('/create_new',[
        'uses' => 'UserController@getCreate_new',
        'as' => 'user.create_new'
    ]);
    
    Route::post('/submit_new_lead',[
        'uses' => 'UserController@submit_new_lead',
        'as' => 'user.submit_new_lead'
    ]);

    Route::post('/get_all_leads',[
        'uses' => 'UserController@get_all_leads',
        'as' => 'user.get_all_leads'
    ]);

    Route::post('/get_lead_info',[
        'uses' => 'UserController@get_lead_info',
        'as' => 'user.get_lead_info'
    ]);

    Route::post('/get_all_leads_marketer',[
        'uses' => 'UserController@get_all_leads_marketer',
        'as' => 'user.get_all_leads_marketer'
    ]);

    Route::post('/get_marketer',[
        'uses' => 'UserController@get_marketer',
        'as' => 'user.get_marketer'
    ]);

    Route::post('/all_agents',[
        'uses' => 'UserController@all_agents',
        'as' => 'user.all_agents'
    ]);

    Route::post('/change_agent_status',[
        'uses' => 'UserController@change_agent_status',
        'as' => 'user.change_agent_status'
    ]);

    Route::post('/change_application_status',[
        'uses' => 'UserController@change_application_status',
        'as' => 'user.change_application_status'
    ]);
	
	Route::post('/change_document_status',[
        'uses' => 'UserController@change_document_status',
        'as' => 'user.change_document_status'
    ]);
	
	Route::post('/in_repository',[
        'uses' => 'UserController@in_repository',
        'as' => 'user.in_repository'
    ]);

    Route::post('/new_chat_message',[
        'uses' => 'UserController@new_chat_message',
        'as' => 'user.new_chat_message'
    ]);

    Route::post('/chat_history',[
        'uses' => 'UserController@chat_history',
        'as' => 'user.chat_history'
    ]);

    Route::post('/lead_message',[
        'uses' => 'UserController@lead_message',
        'as' => 'user.lead_message'
    ]);
	
	Route::post('/get_agent_lead_message',[
        'uses' => 'UserController@get_agent_lead_message',
        'as' => 'user.get_agent_lead_message'
    ]);

    Route::post('/upload_new_document',[
        'uses' => 'UserController@upload_new_document',
        'as' => 'user.upload_new_document'
    ]);

});

Route::group(['prefix' => 'admin'], function(){
    Route::get('/admin',[
        'uses' => 'AdminController@getadmin',
        'as' => 'admin.admin'
    ]);
    
    Route::post('/admin',[
        'uses' => 'AdminController@postadmin_login',
        'as' => 'admin.admin'
    ]);

    Route::get('/dashboard',[
        'uses' => 'AdminController@getDashboard',
        'as' => 'admin.dashboard'
    ]);

    Route::post('/get_leads',[
        'uses' => 'AdminController@get_leads',
        'as' => 'admin.get_leads'
    ]);

    Route::post('/get_lead_info',[
        'uses' => 'AdminController@get_lead_info',
        'as' => 'admin.get_lead_info'
    ]);

    Route::post('/get_agents',[
        'uses' => 'AdminController@get_agents',
        'as' => 'admin.get_agents'
    ]);

    Route::post('/get_marketers',[
        'uses' => 'AdminController@get_marketers',
        'as' => 'admin.get_marketers'
    ]);

    Route::get('/logout',[
        'uses' => 'AdminController@adminLogout',
        'as' => 'admin.logout'
    ]);
});
//Route::get('admin', URL::to('admin'));
Route::get('importExport', 'MaatwebsiteDemoController@importExport');
Route::get('agents/{type}/{startDate}/{stopDate}', 'MaatwebsiteDemoController@agents');
Route::get('leads/{type}/{startDate}/{stopDate}', 'MaatwebsiteDemoController@leads');
Route::get('leadsacceptreject/{type}/{startDate}/{stopDate}', 'MaatwebsiteDemoController@leadsacceptreject');
Route::get('leads_per_agent/{type}/{startDate}/{stopDate}', 'MaatwebsiteDemoController@leads_per_agent');
Route::get('leads_closing_per_marketer/{type}/{startDate}/{stopDate}', 'MaatwebsiteDemoController@leads_closing_per_marketer');
Route::post('importExcel', 'MaatwebsiteDemoController@importExcel');
Route::get('downloadZip', 'HomeController@downloadZip');
Route::get('create','HomeController@create');
Route::get('index', 'HomeController@index');